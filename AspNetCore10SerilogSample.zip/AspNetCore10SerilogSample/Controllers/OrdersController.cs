using AspNetCore10SerilogSample.Models;
using AspNetCore10SerilogSample.Services;
using Microsoft.AspNetCore.Mvc;

namespace AspNetCore10SerilogSample.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
        {
            _orderService = orderService;
            _logger = logger;
        }

        /// <summary>GET /api/orders</summary>
        [HttpGet]
        public async Task<ActionResult<IReadOnlyList<Order>>> GetOrders(CancellationToken cancellationToken)
        {
            _logger.LogInformation("GET /api/orders called");
            var orders = await _orderService.GetOrdersAsync(cancellationToken);
            return Ok(orders);
        }

        /// <summary>GET /api/orders/{id}</summary>
        [HttpGet("{id:int}")]
        public async Task<ActionResult<Order>> GetOrder(int id, CancellationToken cancellationToken)
        {
            _logger.LogInformation("GET /api/orders/{OrderId} called", id);
            var order = await _orderService.GetOrderByIdAsync(id, cancellationToken);
            if (order is null)
                return NotFound(new { Message = $"Order {id} not found" });
            return Ok(order);
        }

        /// <summary>POST /api/orders</summary>
        [HttpPost]
        public async Task<ActionResult<Order>> CreateOrder([FromBody] CreateOrderRequest request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.CustomerName) || request.Amount <= 0)
                return BadRequest(new { Message = "CustomerName and positive Amount are required." });

            _logger.LogInformation("POST /api/orders for customer {CustomerName}", request.CustomerName);
            var order = await _orderService.CreateOrderAsync(request, cancellationToken);
            return CreatedAtAction(nameof(GetOrder), new { id = order.OrderId }, order);
        }

        /// <summary>POST /api/orders/{id}/process</summary>
        [HttpPost("{id:int}/process")]
        public async Task<ActionResult> ProcessOrder(int id, CancellationToken cancellationToken)
        {
            _logger.LogInformation("POST /api/orders/{OrderId}/process", id);
            var ok = await _orderService.ProcessOrderAsync(id, cancellationToken);
            if (!ok)
                return NotFound(new { Message = $"Order {id} not found or could not be processed" });
            return Ok(new { Message = $"Order {id} processed successfully" });
        }
    }
}

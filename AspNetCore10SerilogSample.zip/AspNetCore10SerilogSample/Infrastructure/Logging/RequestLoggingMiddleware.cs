using System.Diagnostics;
using AspNetCore10SerilogSample.Infrastructure.Enrichers;
using AspNetCore10SerilogSample.Infrastructure.Registration;
using Microsoft.Extensions.Options;

namespace AspNetCore10SerilogSample.Infrastructure.Logging
{
    /// <summary>
    /// Middleware that mirrors the ApiLoggingInterceptor behaviour for HTTP requests:
    /// sets TraceId, logs ApiEntry / ApiExit / ApiError with DurationMs, Class, Method, etc.
    /// </summary>
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestLoggingMiddleware> _logger;
        private readonly LoggingOptions _options;

        public RequestLoggingMiddleware(
            RequestDelegate next,
            ILogger<RequestLoggingMiddleware> logger,
            IOptions<LoggingOptions> options)
        {
            _next = next;
            _logger = logger;
            _options = options.Value;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (!_options.Enabled)
            {
                await _next(context);
                return;
            }

            // Prefer incoming correlation / trace header, otherwise generate one
            var incomingTrace = context.Request.Headers["X-Trace-Id"].FirstOrDefault()
                                ?? context.Request.Headers["X-Correlation-Id"].FirstOrDefault();

            var traceId = string.IsNullOrWhiteSpace(incomingTrace)
                ? TraceIdHelper.Generate("API")
                : incomingTrace;

            context.Response.Headers["X-Trace-Id"] = traceId;

            using (TraceContext.BeginScope(traceId))
            {
                var path = context.Request.Path.Value ?? "/";
                var method = context.Request.Method;
                var className = "HttpRequest";
                var methodName = $"{method} {path}";

                _logger.LogInformation(
                    "{@ApiEntry}",
                    new
                    {
                        Direction = "IN",
                        Class = className,
                        Method = methodName,
                        Args = _options.EnableArgumentLogging
                            ? new { Query = context.Request.QueryString.Value, Path = path }
                            : null
                    });

                var sw = Stopwatch.StartNew();
                try
                {
                    await _next(context);
                    sw.Stop();

                    _logger.LogInformation(
                        "{@ApiExit}",
                        new
                        {
                            Direction = "OUT",
                            Class = className,
                            Method = methodName,
                            DurationMs = sw.ElapsedMilliseconds,
                            StatusCode = context.Response.StatusCode
                        });
                }
                catch (Exception ex)
                {
                    sw.Stop();
                    _logger.LogError(
                        ex,
                        "{@ApiError}",
                        new
                        {
                            Direction = "ERR",
                            Class = className,
                            Method = methodName,
                            DurationMs = sw.ElapsedMilliseconds,
                            Error = ex.Message
                        });
                    throw;
                }
            }
        }
    }
}

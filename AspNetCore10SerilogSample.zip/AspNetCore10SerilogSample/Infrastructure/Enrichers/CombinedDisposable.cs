namespace AspNetCore10SerilogSample.Infrastructure.Enrichers
{
    internal class CombinedDisposable : IDisposable
    {
        private readonly IDisposable _logContextDisposable;
        private readonly Action _undoAction;

        public CombinedDisposable(IDisposable logContextDisposable, Action undoAction)
        {
            _logContextDisposable = logContextDisposable;
            _undoAction = undoAction;
        }

        public void Dispose()
        {
            _logContextDisposable.Dispose();
            _undoAction.Invoke();
        }
    }
}

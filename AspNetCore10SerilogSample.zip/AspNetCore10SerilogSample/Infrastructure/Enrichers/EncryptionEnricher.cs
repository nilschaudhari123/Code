using AspNetCore10SerilogSample.Infrastructure.Registration;
using Serilog.Core;
using Serilog.Events;

namespace AspNetCore10SerilogSample.Infrastructure.Enrichers
{
    public class EncryptionEnricher : ILogEventEnricher
    {
        private readonly LoggingOptions _options;
        private readonly LogEncryptionService _encryptionService;

        public EncryptionEnricher(LoggingOptions options, LogEncryptionService encryptionService)
        {
            _options = options;
            _encryptionService = encryptionService;
        }

        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {
            if (!_options.EncryptNonWhitelisted) return;

            var propertyKeys = logEvent.Properties.Keys.ToList();

            foreach (var key in propertyKeys)
            {
                if (_options.WhitelistIdentifiers.Contains(key))
                    continue;

                var propValue = logEvent.Properties[key];

                string rawValue = propValue is ScalarValue scalar
                    ? scalar.Value?.ToString() ?? string.Empty
                    : propValue.ToString() ?? string.Empty;

                if (!string.IsNullOrEmpty(rawValue))
                {
                    var encrypted = _encryptionService.Encrypt(rawValue);
                    logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty(key, encrypted));
                }
            }
        }
    }
}

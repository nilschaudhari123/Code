namespace AspNetCore10SerilogSample.Infrastructure.Enrichers
{
    public static class TraceIdHelper
    {
        /// <summary>
        /// Generates a structured TraceId. If prefix is null, defaults to 'GEN'.
        /// </summary>
        public static string Generate(string? prefix = null)
        {
            var cleanPrefix = string.IsNullOrWhiteSpace(prefix)
                ? "GEN"
                : prefix.Trim().ToUpperInvariant();

            var uniquePart = Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
            return $"{cleanPrefix}_{uniquePart}";
        }
    }
}

using AspNetCore10SerilogSample.Infrastructure.Enrichers;
using Serilog;

namespace AspNetCore10SerilogSample.Infrastructure.Registration
{
    public static class LoggingRegistration
    {
        public static void ConfigureLogging(LoggerConfiguration loggerConfig, LoggingConfig config, LogEncryptionService encryptionService)
        {
            var orderedFields = config.Options?.OrderedFields ?? new List<string>();
            var formatter = new OrderedFlatJsonFormatter(orderedFields);

            loggerConfig
                .MinimumLevel.Information()
                .Enrich.FromLogContext()
                .Enrich.With<GlobalContextEnricher>()
                .Enrich.With<FlatStructureEnricher>();

            if (string.IsNullOrEmpty(config.EncryptionKey) || string.IsNullOrEmpty(config.EncryptionIV))
            {
                throw new InvalidOperationException("Logging Encryption keys are missing in appsettings.json (EncryptionKey / EncryptionIV).");
            }

            if (config.Options?.Enabled == true && config.Options.EncryptNonWhitelisted)
            {
                loggerConfig.Enrich.With(new EncryptionEnricher(config.Options, encryptionService));
            }

            var basePath = config.BasePath ?? Path.Combine(AppContext.BaseDirectory, "Logs");

            if (string.Equals(config.ContextType, "API", StringComparison.OrdinalIgnoreCase))
            {
                string path = Path.Combine(basePath, "API", "accmgmt", "accmgmt-.json");
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);

                loggerConfig
                    .WriteTo.Async(c => c.Console(new OrderedFlatJsonFormatter(orderedFields)))
                    .WriteTo.Async(f => f.File(
                        formatter: new OrderedFlatJsonFormatter(orderedFields),
                        path: path,
                        rollingInterval: RollingInterval.Day));
            }
            else
            {
                string date = DateTimeOffset.Now.ToString("yyyyMMdd");
                string time = DateTimeOffset.Now.ToString("HHmm");
                string jobName = config.JobName ?? "DefaultJob";
                string path = Path.Combine(basePath, config.ContextType ?? "Batch", jobName, $"{jobName}_{date}_{time}.json");
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);

                loggerConfig
                    .WriteTo.Console(new OrderedFlatJsonFormatter(orderedFields))
                    .WriteTo.File(
                        formatter: new OrderedFlatJsonFormatter(orderedFields),
                        path: path);
            }
        }
    }
}

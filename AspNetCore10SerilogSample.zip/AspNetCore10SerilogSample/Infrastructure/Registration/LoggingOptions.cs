namespace AspNetCore10SerilogSample.Infrastructure.Registration
{
    public class LoggingOptions
    {
        public bool Enabled { get; set; } = true;
        public bool EnableArgumentLogging { get; set; } = true;
        public bool LogCancellationToken { get; set; } = false;
        public bool LogCancellationTokenDetails { get; set; } = false;
        public bool EncryptNonWhitelisted { get; set; } = true;
        public List<string> WhitelistIdentifiers { get; set; } = new();
        public List<string> OrderedFields { get; set; } = new();
    }
}

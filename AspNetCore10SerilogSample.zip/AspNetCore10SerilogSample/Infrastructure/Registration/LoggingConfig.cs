namespace AspNetCore10SerilogSample.Infrastructure.Registration
{
    public class LoggingConfig
    {
        public string ContextType { get; set; } = "API";
        public string? JobName { get; set; }
        public string? BasePath { get; set; }
        public string? EncryptionKey { get; set; }
        public string? EncryptionIV { get; set; }
        public LoggingOptions? Options { get; set; }
    }
}

using AspNetCore10SerilogSample.Infrastructure.Enrichers;
using Serilog;

namespace AspNetCore10SerilogSample.Infrastructure.Registration
{
    public static class LoggingExtensions
    {
        /// <summary>
        /// Configures Serilog for ASP.NET Core host using the same pattern as the sample project.
        /// </summary>
        public static WebApplicationBuilder UseSerilogLogger(this WebApplicationBuilder builder)
        {
            builder.Host.UseSerilog((context, services, loggerConfig) =>
            {
                var loggingConfig = context.Configuration.GetSection("LoggingConfig").Get<LoggingConfig>();
                if (loggingConfig == null)
                    throw new InvalidOperationException("LoggingConfig section is missing in configuration.");

                var encryptionService = new LogEncryptionService(
                    loggingConfig.EncryptionKey ?? string.Empty,
                    loggingConfig.EncryptionIV ?? string.Empty
                );

                LoggingRegistration.ConfigureLogging(loggerConfig, loggingConfig, encryptionService);
            });

            return builder;
        }

        public static void LogCriticalError(Exception ex, string message)
        {
            Log.Fatal(ex, message);
        }

        public static void LogStartupInfo(string message, params object[] args)
        {
            Log.Information(message, args);
        }

        public static void CloseAndFlush()
        {
            Log.CloseAndFlush();
        }
    }
}

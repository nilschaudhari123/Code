# ASP.NET Core 10 + Serilog Sample

Fully functional ASP.NET Core 10 Web API that implements **Serilog** using the same architecture and patterns as the attached **AccountManagement-Batch** sample project.

## Features (aligned with the sample)

| Feature | Description |
|--------|-------------|
| **LoggingConfig** | Bound from `appsettings.json` (`ContextType`, `BasePath`, encryption keys, options) |
| **OrderedFlatJsonFormatter** | Emits flat JSON with fields in the exact order defined in config |
| **GlobalContextEnricher** | Injects `ContextType`, `RunId`, `TraceId`, `RecIdentifier`, `RecValue` on every log |
| **FlatStructureEnricher** | Flattens structured `{@ApiEntry}` / `{@ApiExit}` / `{@ApiError}` objects |
| **EncryptionEnricher** | Optionally encrypts non-whitelisted property values (AES) |
| **LogEncryptionService** | AES encrypt/decrypt used by the enricher |
| **TraceContext / RunContext** | AsyncLocal + static context for correlation across the request |
| **RequestLoggingMiddleware** | API equivalent of `ApiLoggingInterceptor` – logs entry/exit/error with duration |
| **Rolling file + Console** | Async sinks writing ordered JSON under `Logs/API/accmgmt/` |

## Project structure

```
AspNetCore10SerilogSample/
├── Controllers/
│   └── OrdersController.cs
├── Models/
│   └── Order.cs
├── Services/
│   ├── IOrderService.cs
│   └── OrderService.cs
├── Infrastructure/
│   ├── Enrichers/          # Same as sample
│   │   ├── CombinedDisposable.cs
│   │   ├── EncryptionEnricher.cs
│   │   ├── FlatStructureEnricher.cs
│   │   ├── GlobalContextEnricher.cs
│   │   ├── LogEncryptionService.cs
│   │   ├── OrderedFlatJsonFormatter.cs
│   │   ├── RunContext.cs
│   │   ├── TraceContext.cs
│   │   └── TraceIdHelper.cs
│   ├── Logging/
│   │   └── RequestLoggingMiddleware.cs
│   └── Registration/
│       ├── LoggingConfig.cs
│       ├── LoggingOptions.cs
│       ├── LoggingRegistration.cs
│       └── LoggingExtensions.cs
├── Program.cs
├── appsettings.json
└── AspNetCore10SerilogSample.csproj
```

## Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download) (or .NET 9 – change `TargetFramework` if needed)

## Run

```bash
cd AspNetCore10SerilogSample
dotnet restore
dotnet run
```

API listens on `http://localhost:5080`.

### Try it

```bash
# List orders
curl http://localhost:5080/api/orders

# Get one order
curl http://localhost:5080/api/orders/1

# Create order
curl -X POST http://localhost:5080/api/orders \
  -H "Content-Type: application/json" \
  -d '{"customerName":"Charlie","amount":42.50}'

# Process order
curl -X POST http://localhost:5080/api/orders/1/process
```

Pass a correlation id:

```bash
curl -H "X-Trace-Id: MYTRACE_ABC123" http://localhost:5080/api/orders
```

## Log output

- **Console**: ordered flat JSON lines
- **File**: `Logs/API/accmgmt/accmgmt-YYYYMMDD.json` (rolling daily)

Example log line shape:

```json
{"Timestamp":"2026-10-06T07:40:00.1234567+00:00","Level":"Information","ContextType":"API","RunId":"API_12345_20261006_0740","TraceId":"API_A1B2C3D4","Message":"Retrieving all orders. Count=2","Class":"HttpRequest","Method":"GET /api/orders","DurationMs":12,"Direction":"OUT"}
```

## Configuration (`appsettings.json`)

```json
"LoggingConfig": {
  "ContextType": "API",
  "BasePath": "Logs",
  "EncryptionKey": "6fG9pQ2nR5xT8vW1zB4yM7kL3pS6aN9u",
  "EncryptionIV": "MTIzNDU2Nzg5MDEyMzQ1Ng==",
  "Options": {
    "Enabled": true,
    "EnableArgumentLogging": true,
    "EncryptNonWhitelisted": true,
    "WhitelistIdentifiers": [ "Timestamp", "Level", "ContextType", ... ],
    "OrderedFields": [ "Timestamp", "Level", "ContextType", ... ]
  }
}
```

- Set `EncryptNonWhitelisted` to `false` in Development if you want readable non-whitelisted fields.
- `BasePath` can be absolute (e.g. `D:\\Data\\Logs`) or relative.

## Mapping to the original sample

| Sample (Batch) | This project (API) |
|----------------|--------------------|
| `UseSerilogLogger(jobName)` on `IHostBuilder` | `builder.UseSerilogLogger()` on `WebApplicationBuilder` |
| `SerilogConfigurator` / `LoggingRegistration.ConfigureLogging` | Same `LoggingRegistration.ConfigureLogging` |
| `ApiLoggingInterceptor` (Castle) | `RequestLoggingMiddleware` (HTTP pipeline) |
| `ContextType = "Batch"` + JobName | `ContextType = "API"` |
| File path: `{BasePath}/Batch/{JobName}/...` | File path: `{BasePath}/API/accmgmt/accmgmt-.json` |

The enrichers, formatter, encryption service, and config model are direct ports of the attached sample.

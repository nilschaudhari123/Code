using AspNetCore10SerilogSample.Infrastructure.Enrichers;
using AspNetCore10SerilogSample.Infrastructure.Logging;
using AspNetCore10SerilogSample.Infrastructure.Registration;
using AspNetCore10SerilogSample.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------------
// 1. Serilog – same pattern as AccountManagement sample (LoggingConfig section)
// ---------------------------------------------------------------------------
builder.UseSerilogLogger();

// Bind LoggingOptions so middleware / interceptors can read flags
builder.Services.Configure<LoggingOptions>(
    builder.Configuration.GetSection("LoggingConfig:Options"));

// ---------------------------------------------------------------------------
// 2. Application services
// ---------------------------------------------------------------------------
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApi();
builder.Services.AddScoped<IOrderService, OrderService>();

var app = builder.Build();

// ---------------------------------------------------------------------------
// 3. Initialize RunContext (ContextType + RunId) – same as sample
// ---------------------------------------------------------------------------
var loggingConfig = app.Configuration.GetSection("LoggingConfig").Get<LoggingConfig>();
RunContext.Initialize(loggingConfig?.ContextType ?? "API");

// ---------------------------------------------------------------------------
// 4. Pipeline
// ---------------------------------------------------------------------------
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseMiddleware<RequestLoggingMiddleware>();

app.MapControllers();

// Health / root
app.MapGet("/", () => Results.Ok(new
{
    Application = "AspNetCore10SerilogSample",
    ContextType = RunContext.ContextType,
    RunId = RunContext.RunId,
    Message = "Serilog is configured. Call /api/orders to generate structured logs."
}));

try
{
    LoggingExtensions.LogStartupInfo(
        "ASP.NET Core API started. ContextType={ContextType}, RunId={RunId}",
        RunContext.ContextType,
        RunContext.RunId);

    app.Run();
}
catch (Exception ex)
{
    LoggingExtensions.LogCriticalError(ex, "Host terminated unexpectedly");
    throw;
}
finally
{
    LoggingExtensions.CloseAndFlush();
}

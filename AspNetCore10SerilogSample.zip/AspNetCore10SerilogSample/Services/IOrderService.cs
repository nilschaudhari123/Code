using AspNetCore10SerilogSample.Models;

namespace AspNetCore10SerilogSample.Services
{
    public interface IOrderService
    {
        Task<IReadOnlyList<Order>> GetOrdersAsync(CancellationToken cancellationToken = default);
        Task<Order?> GetOrderByIdAsync(int orderId, CancellationToken cancellationToken = default);
        Task<Order> CreateOrderAsync(CreateOrderRequest request, CancellationToken cancellationToken = default);
        Task<bool> ProcessOrderAsync(int orderId, CancellationToken cancellationToken = default);
    }
}

using System.Collections.Concurrent;
using AspNetCore10SerilogSample.Infrastructure.Enrichers;
using AspNetCore10SerilogSample.Models;

namespace AspNetCore10SerilogSample.Services
{
    public class OrderService : IOrderService
    {
        private readonly ILogger<OrderService> _logger;
        private static readonly ConcurrentDictionary<int, Order> _store = new();
        private static int _nextId = 1;

        public OrderService(ILogger<OrderService> logger)
        {
            _logger = logger;

            // Seed sample data once
            if (_store.IsEmpty)
            {
                _store.TryAdd(1, new Order { OrderId = 1, CustomerName = "Alice", Amount = 150.00m, Status = "Pending" });
                _store.TryAdd(2, new Order { OrderId = 2, CustomerName = "Bob", Amount = 299.99m, Status = "Completed" });
                Interlocked.Exchange(ref _nextId, 3);
            }
        }

        public Task<IReadOnlyList<Order>> GetOrdersAsync(CancellationToken cancellationToken = default)
        {
            using (TraceContext.BeginScope(TraceContext.TraceId, "Action", "GetOrders"))
            {
                _logger.LogInformation("Retrieving all orders. Count={Count}", _store.Count);
                var list = _store.Values.OrderBy(o => o.OrderId).ToList() as IReadOnlyList<Order>;
                return Task.FromResult(list);
            }
        }

        public Task<Order?> GetOrderByIdAsync(int orderId, CancellationToken cancellationToken = default)
        {
            using (TraceContext.BeginScope(TraceContext.TraceId, "OrderId", orderId.ToString()))
            {
                _logger.LogInformation("Looking up order {OrderId}", orderId);
                _store.TryGetValue(orderId, out var order);
                if (order is null)
                    _logger.LogWarning("Order {OrderId} not found", orderId);
                return Task.FromResult(order);
            }
        }

        public Task<Order> CreateOrderAsync(CreateOrderRequest request, CancellationToken cancellationToken = default)
        {
            var id = Interlocked.Increment(ref _nextId) - 1;
            var order = new Order
            {
                OrderId = id,
                CustomerName = request.CustomerName,
                Amount = request.Amount,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            using (TraceContext.BeginScope(TraceContext.TraceId, "OrderId", order.OrderId.ToString()))
            {
                _store[order.OrderId] = order;
                _logger.LogInformation(
                    "Created order {OrderId} for customer {CustomerName} amount {Amount}",
                    order.OrderId, order.CustomerName, order.Amount);
            }

            return Task.FromResult(order);
        }

        public Task<bool> ProcessOrderAsync(int orderId, CancellationToken cancellationToken = default)
        {
            using (TraceContext.BeginScope(TraceContext.TraceId, "OrderId", orderId.ToString()))
            {
                if (!_store.TryGetValue(orderId, out var order))
                {
                    _logger.LogWarning("Cannot process missing order {OrderId}", orderId);
                    return Task.FromResult(false);
                }

                if (order.Status == "Completed")
                {
                    _logger.LogInformation("Order {OrderId} already completed", orderId);
                    return Task.FromResult(true);
                }

                order.Status = "Completed";
                _logger.LogInformation("Processed order {OrderId} successfully", orderId);
                return Task.FromResult(true);
            }
        }
    }
}
